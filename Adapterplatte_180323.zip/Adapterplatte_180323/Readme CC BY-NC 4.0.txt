;
;===YouTube CNC-DOZENT===
;
;Dieses Werk ist lizenziert unter einer Creative Commons Namensnennung-Nicht kommerziell 4.0 International Lizenz
;https://creativecommons.org/licenses/by-nc/4.0/deed.de
;
;cncdozent@gmail.com
;